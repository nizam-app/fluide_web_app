import { useState } from 'react'
import { Box, Button, Collapsible, Flex, Grid, Input, Text } from '@chakra-ui/react'
import { Link as RouterLink, Navigate, useLocation, useNavigate } from 'react-router-dom'
import { AccountTypeCard } from '../components/molecules/AccountTypeCard'
import { DemoCredentialsPanel } from '../components/molecules/DemoCredentialsPanel'
import { MaterialIcon } from '../components/atoms/MaterialIcon'
import { useAuth } from '../context/AuthContext'
import { accountTypeOptions } from '../data/mockData'
import { getHomePath, ROLES } from '../lib/roles'
import { BrandName } from '../components/atoms/BrandName'
import { fluideInputStyles, stitchBlackButton } from '../theme/fluide-theme'

const SHOW_DEMO = import.meta.env.DEV

function AccountTypePicker({ accountType, onChange }) {
  return (
    <Grid templateColumns={{ base: '1fr', sm: '1fr 1fr' }} gap="3">
      {accountTypeOptions.map((opt) => (
        <AccountTypeCard key={opt.value} {...opt} checked={accountType === opt.value} onChange={() => onChange(opt.value)} />
      ))}
    </Grid>
  )
}

function SecurityNote() {
  return (
    <Flex align="center" gap="2" p="3" borderRadius="fluide" bg="surfaceContainerLow" borderWidth="1px" borderColor="outlineVariant">
      <MaterialIcon name="lock" size={16} color="primary" />
      <Text textStyle="bodySm" color="onSurfaceVariant">
        Secure connection – your data is protected.
      </Text>
    </Flex>
  )
}

export function AuthPage() {
  const [tab, setTab] = useState('login')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [fullName, setFullName] = useState('')
  const [accountType, setAccountType] = useState(ROLES.ORGANIZER)
  const [error, setError] = useState('')
  const [showDemo, setShowDemo] = useState(false)
  const { login, register, isAuthenticated, user } = useAuth()
  const navigate = useNavigate()
  const location = useLocation()

  const from = location.state?.from

  if (isAuthenticated && user) {
    const target = from ?? getHomePath(user.role)
    return <Navigate to={target} replace />
  }

  const handleLogin = (e) => {
    e.preventDefault()
    setError('')
    if (!email.trim() || !password.trim()) {
      setError('Email and password are required.')
      return
    }
    try {
      const session = login({ email, accountType })
      navigate(from ?? getHomePath(session.role), { replace: true })
    } catch (err) {
      setError(err.message ?? 'Login failed.')
    }
  }

  const fillDemoCredential = (cred) => {
    setEmail(cred.email)
    setPassword(cred.password)
    setError('')
    if (cred.role === ROLES.ORGANIZER || cred.role === ROLES.PROVIDER) {
      setAccountType(cred.role)
    }
    if (tab !== 'login') setTab('login')
  }

  const handleSignUp = (e) => {
    e.preventDefault()
    setError('')
    if (!email.trim() || !password.trim()) {
      setError('Email and password are required.')
      return
    }
    try {
      const session = register({
        email,
        password,
        accountType,
        name: fullName,
        organizationType: accountType === ROLES.ORGANIZER ? 'Municipality' : undefined,
        providerType: accountType === ROLES.PROVIDER ? 'Transport' : undefined,
      })
      navigate(getHomePath(session.role), { replace: true })
    } catch (err) {
      setError(err.message ?? 'Sign up failed.')
    }
  }

  return (
    <Flex minH="100vh" bg="surface" direction="column">
      <Flex justify="center" pt={{ base: 6, md: 8 }} pb="2" px="6">
        <RouterLink to="/">
          <Flex align="center" gap="2">
            <MaterialIcon name="eco" size={26} color="primary" />
            <BrandName as="span" uppercase fontSize="lg" fontWeight="800" letterSpacing="0.05em" color="onSurface">
              Flunexia
            </BrandName>
          </Flex>
        </RouterLink>
      </Flex>

      <Flex flex="1" align="flex-start" justify="center" px={{ base: 5, md: 6 }} pb="10">
        <Box w="full" maxW="md">
          <Flex borderBottomWidth="1px" borderColor="outlineVariant" mb="6" gap="8" justify="center">
            {[
              { id: 'login', label: 'Log in' },
              { id: 'register', label: 'Sign up' },
            ].map(({ id, label }) => (
              <Button
                key={id}
                unstyled
                pb="3"
                textStyle="labelMd"
                fontWeight="600"
                color={tab === id ? 'onSurface' : 'onSurfaceVariant'}
                borderBottomWidth="3px"
                borderColor={tab === id ? 'primary' : 'transparent'}
                onClick={() => {
                  setTab(id)
                  setError('')
                }}
              >
                {label}
              </Button>
            ))}
          </Flex>

          {tab === 'login' ? (
            <>
              <Text textStyle="headlineMd" mb="5" textAlign="center">
                Log in to your space
              </Text>
              <Flex as="form" direction="column" gap="4" onSubmit={handleLogin}>
                <AccountTypePicker accountType={accountType} onChange={setAccountType} />
                <Box>
                  <Text textStyle="labelMd" mb="2">
                    Email
                  </Text>
                  <Input
                    type="email"
                    placeholder="name@organization.fr"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    css={fluideInputStyles}
                    size="lg"
                  />
                </Box>
                <Box>
                  <Flex justify="space-between" mb="2">
                    <Text textStyle="labelMd">Password</Text>
                    <Text textStyle="labelSm" color="primary" cursor="pointer">
                      Forgot password?
                    </Text>
                  </Flex>
                  <Input
                    type="password"
                    placeholder="••••••••"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    css={fluideInputStyles}
                    size="lg"
                  />
                </Box>
                {error && (
                  <Text textStyle="bodySm" color="error">
                    {error}
                  </Text>
                )}
                <Button w="full" py="4" type="submit" {...stitchBlackButton} fontSize="md">
                  Log in
                </Button>
                <SecurityNote />
              </Flex>

              {SHOW_DEMO && (
                <Box mt="4">
                  <Button
                    variant="ghost"
                    size="sm"
                    w="full"
                    color="onSurfaceVariant"
                    onClick={() => setShowDemo((v) => !v)}
                  >
                    <MaterialIcon name={showDemo ? 'expand_less' : 'expand_more'} size={18} />
                    {showDemo ? 'Hide' : 'Show'} demo access (testing)
                  </Button>
                  <Collapsible.Root open={showDemo}>
                    <Collapsible.Content>
                      <DemoCredentialsPanel onUseCredential={fillDemoCredential} />
                    </Collapsible.Content>
                  </Collapsible.Root>
                </Box>
              )}

              <Text textStyle="bodySm" color="onSurfaceVariant" mt="6" textAlign="center">
                No account?{' '}
                <Button unstyled textStyle="labelMd" color="primary" fontWeight="600" onClick={() => setTab('register')}>
                  Sign up
                </Button>
              </Text>
            </>
          ) : (
            <>
              <Text textStyle="headlineMd" mb="5" textAlign="center">
                Create your account
              </Text>
              <Flex as="form" direction="column" gap="4" onSubmit={handleSignUp}>
                <AccountTypePicker accountType={accountType} onChange={setAccountType} />
                <Box>
                  <Text textStyle="labelMd" mb="2">
                    Full name
                  </Text>
                  <Input
                    placeholder="Alex Morgan"
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    css={fluideInputStyles}
                    size="lg"
                  />
                </Box>
                <Box>
                  <Text textStyle="labelMd" mb="2">
                    Email
                  </Text>
                  <Input
                    type="email"
                    placeholder="you@organization.fr"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    css={fluideInputStyles}
                    size="lg"
                  />
                </Box>
                <Box>
                  <Text textStyle="labelMd" mb="2">
                    Password
                  </Text>
                  <Input
                    type="password"
                    placeholder="••••••••"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    css={fluideInputStyles}
                    size="lg"
                  />
                </Box>
                {error && (
                  <Text textStyle="bodySm" color="error">
                    {error}
                  </Text>
                )}
                <Button w="full" py="4" type="submit" {...stitchBlackButton} fontSize="md">
                  Sign up
                </Button>
                <SecurityNote />
              </Flex>
              <Text textStyle="bodySm" color="onSurfaceVariant" mt="6" textAlign="center">
                Already registered?{' '}
                <Button unstyled textStyle="labelMd" color="primary" fontWeight="600" onClick={() => setTab('login')}>
                  Log in
                </Button>
              </Text>
            </>
          )}
        </Box>
      </Flex>
    </Flex>
  )
}
